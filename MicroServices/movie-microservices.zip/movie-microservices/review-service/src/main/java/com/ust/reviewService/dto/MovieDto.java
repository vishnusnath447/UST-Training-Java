package com.ust.reviewService.dto;

public record MovieDto(int movieId,String title) {
}
