package com.ust.reviewService.dto;

public record CustomerDto(int customerId,String name,String email) {
}
